<?php 
	session_start();
	$log = array();

	if(@$_SESSION['id']){
		$log['cod'] = 1;

		$return = ($_POST['id']) ? $_POST['id'] : 0;
		$log['result'] = $return;
	} else {
		$log['cod'] = 0;
		$log['message'] = 'Acesso negado';
	}

	if(isset($log)){
		echo json_encode($log);
	}
?>